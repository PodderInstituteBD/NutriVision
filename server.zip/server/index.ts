import { spawn } from 'child_process';
import { resolve } from 'path';

const pythonProcess = spawn('python', ['run.py'], {
  stdio: 'inherit',
  cwd: resolve(process.cwd())
});

pythonProcess.on('close', (code) => {
  process.exit(code || 0);
});